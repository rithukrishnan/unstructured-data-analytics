# Text Analytics
This contains code and analysis done for UT Austin's Text Analytics class which involved unstructured data. 
